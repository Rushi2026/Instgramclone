import React, { useEffect, useState } from "react";
import { FlatList, Image, Text, View } from "react-native";
import { collection, onSnapshot, orderBy, query } from "firebase/firestore";
import { db } from "../firebase";

export default function HomeScreen() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "posts"), orderBy("createdAt", "desc"));
    return onSnapshot(q, (snapshot) =>
      setPosts(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })))
    );
  }, []);

  return (
    <FlatList
      data={posts}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <View style={{ marginBottom: 20 }}>
          <Image source={{ uri: item.image }} style={{ width: "100%", height: 300 }} />
          <Text>{item.caption}</Text>
          <Text>By: {item.email}</Text>
        </View>
      )}
    />
  );
}