import React, { useState } from "react";
import { View, Button, Image, TextInput } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { storage, db, auth } from "../firebase";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";

export default function UploadScreen() {
  const [image, setImage] = useState(null);
  const [caption, setCaption] = useState("");

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images });
    if (!result.canceled) setImage(result.assets[0].uri);
  };

  const uploadPost = async () => {
    if (!image) return alert("Pick an image");

    const response = await fetch(image);
    const blob = await response.blob();
    const imageRef = ref(storage, `posts/${Date.now()}.jpg`);

    await uploadBytes(imageRef, blob);
    const url = await getDownloadURL(imageRef);

    await addDoc(collection(db, "posts"), {
      image: url,
      caption,
      email: auth.currentUser.email,
      createdAt: serverTimestamp(),
    });

    setImage(null);
    setCaption("");
    alert("Post uploaded");
  };

  return (
    <View>
      <Button title="Pick Image" onPress={pickImage} />
      {image && <Image source={{ uri: image }} style={{ width: 200, height: 200 }} />}
      <TextInput placeholder="Caption" value={caption} onChangeText={setCaption} />
      <Button title="Upload Post" onPress={uploadPost} />
    </View>
  );
}